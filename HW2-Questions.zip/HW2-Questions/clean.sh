#!/usr/bin/env bash
rm -f a.out *.cmi *.cmo *.mli calclexer.ml calcparser.ml implexer.ml impparser.ml
